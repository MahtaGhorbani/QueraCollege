def dists_diff(dist_1,dist_2):
    return np.mean(np.subtract(dist_1,dist_2))
