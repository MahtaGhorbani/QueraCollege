import numpy as np
from numpy import unravel_index
import pandas as pd

def max_corr(dataframe):
    df=dataframe.corr().abs()
    n_columns = len(df)
    sol = (df.where(np.triu(np.ones(df.shape), k=1).astype(np.bool))
                 .stack()
                 .sort_values(ascending=False))
    r=set(sol[sol==sol[0]].keys()[0])
    return r