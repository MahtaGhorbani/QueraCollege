import numpy as np
from sklearn.model_selection import KFold,cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier

def kfold_accuracies(model,X,y):
    return cross_val_score(model, X, y, cv=5)
def create_classifier():
    return KNeighborsClassifier()